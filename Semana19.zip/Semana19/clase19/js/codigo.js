function nombre(){
var nombre = prompt('digite el nombre');
document.write(nombre);
}

function edad(){
    var edad = prompt('digite su edad');
    document.write(edad);
}
